<div class="card-pub card " >
                <div class="card-header pub" >
                    <div class="data-pub">
                     <div class="container-avatar">
                           <img src=" <?php echo e(route('user.avatar', ['filename' => $image->user->image])); ?> " class="avatar">
                     </div>

                        <div class="data-user">
                            <a href="<?php echo e(route('profile',['id' => $image->user_id])); ?> "><?php echo e($image->user->name .' |'); ?>

                             <span class="nick">   <?php echo e('@'.$image->user->nickname); ?></span>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="card-pub-body card-body ">
                    <div class="image-container">
                        <a href=" <?php echo e(route('image.detail' , ['id' =>$image->id])); ?>">
                        <img src=" <?php echo e(route('image.file', ['filename' => $image->image_path])); ?> "  >
                    </a>
                    </div>
                    <div class="pub-footer">
                        <div>
                        <div class="likes">
                            <?php $user_like = false?>
                            <?php $__currentLoopData = $image->likes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $like): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if( Auth::user()->id == $like->user_id): ?>
                            <?php $user_like = true?>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($user_like): ?>
                            <img src="<?php echo e(asset('img/heart-red.png')); ?>" data-id="<?php echo e($image->id); ?>" class="heart btn-like" >
                            <?php else: ?>
                            <img src="<?php echo e(asset('img/heart-gray.png')); ?>"  data-id="<?php echo e($image->id); ?>" class="heart btn-dislike" >
                            <?php endif; ?>
                            <span class="likes-count"><?php echo e(count($image->likes)); ?></span>
                        </div>
                            <span class="data-user desc"><?php echo e($image->user->name.'|'); ?></span>
                            
                            <span class="date" ><?php echo e(\FormatTime::LongTimeFilter($image->created_at)); ?></span>
                            <p class="description spacig-letter"><?php echo e($image->description); ?></p>
                        </div>

                        <a href="<?php echo e(route('image.detail',['id' => $image->id])); ?>" class="btn btn-primary btn-info btn-comments">comentarios (<?php echo e(count($image->coments)); ?>)</a>
                        <?php if( mb_stristr(Request::path(),'profile') && Auth::user()->id == $image->user_id): ?>
                        <a href=" <?php echo e(route('image.edit', ['id' => $image->id ])); ?> " class="btn btn-primary btn-outline-warning btn-comments">Editar publicacion</a>

                        <!-- Button trigger modal -->
<button type="button" class="btn btn-primary btn-outline-danger btn-comments" data-toggle="modal" data-target="#exampleModalCenter">
  Eliminar publicacion
</button>

<!-- Modal -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Eliminar publicacion</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Estas seguro que deseas eliminar esta publicacion ? Los datos no se podran recuperar
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <a href="<?php echo e(route('image.delete', ['id' => $image->id])); ?>" class="btn btn-primary btn-danger ">Eliminar publicacion</a></button>
      </div>
    </div>
  </div>
</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div><?php /**PATH C:\wamp64\www\proyecto-laravel\resources\views/includes/pub.blade.php ENDPATH**/ ?>