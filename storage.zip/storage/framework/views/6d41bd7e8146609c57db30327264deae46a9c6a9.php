<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-9">
        <?php echo $__env->make('includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
       
            <div class="card-pub card " >
                <div class="card-header pub" >
                    <div class="data-pub">                      
                        <div class="container-avatar">    
                              <img src=" <?php echo e(route('user.avatar', ['filename' => $image->user->image])); ?> " class="avatar">
                        </div>
                        <div class="data-user">   
                          <a href="<?php echo e(route('profile',['id' => $image->user_id])); ?>">  <?php echo e($image->user->name .' |'); ?>

                           <span class="nick">   <?php echo e('@'.$image->user->nickname); ?></span>       
                           </a> 
                        </div>
                    </div>
                </div>
                <div class="card-pub-body card-body ">
                    <div class="image-container">
                        <img src=" <?php echo e(route('image.file', ['filename' => $image->image_path])); ?> "  >
                    </div>
                    <div class="pub-footer">     
                           <div>            
                           <div class="likes">
                            <?php $user_like = false ?>
                            <?php $__currentLoopData = $image->likes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $like): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if( Auth::user()->id == $like->user_id): ?>
                            <?php $user_like = true ?>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                            <?php if($user_like): ?>  
                            <img src="<?php echo e(asset('img/heart-red.png')); ?>" data-id="<?php echo e($image->id); ?>" class="heart btn-like" >  
                            <?php else: ?>
                            <img src="<?php echo e(asset('img/heart-gray.png')); ?>"  data-id="<?php echo e($image->id); ?>" class="heart btn-dislike" > 
                            <?php endif; ?>    
                            <span class="likes-count" ><?php echo e($image->likes->count()); ?></span>                        
                        </div>
                            <div class="data-user"><?php echo e($image->user->name); ?></div>
                            <span class="date" ><?php echo e(\FormatTime::LongTimeFilter($image->created_at)); ?></span>
                            <p class="description spacig-letter"><?php echo e($image->description); ?></p>
                        </div>
                       <h5>comentarios (<?php echo e(count($image->coments)); ?>)</h5>
                       <form action=" <?php echo e(route('comment.save')); ?> " class="form-comment " method="POST">
                       <?php echo csrf_field(); ?>

                       <input type="hidden" name="image_id" value="<?php echo e($image->id); ?>" >
                       <hr>
                       <p>
                       <textarea name="content" class="form-control spacig-letter <?php echo e($errors->has('content') ? 'is-invalid' : ''); ?>" ></textarea>
                       </p>
                       <input type="submit" value="comentar" class="btn btn-success">
                       </form>
                   
                       <?php $__currentLoopData = $image->coments->reverse(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <hr>
                           <div class="comment">
                       <div class="data-user"><?php echo e($coment->user->nickname); ?></div>
                            <span class="date" ><?php echo e(\FormatTime::LongTimeFilter($coment->created_at)); ?></span>
                            <p class="description spacig-letter"><?php echo e($coment->content); ?></p>
                            <?php if(Auth::check() && Auth::user()->id == $coment->user_id   ): ?>
                            <a href=" <?php echo e(route('comment.delete', $coment->id )); ?>"  class="btn btn-primary de"  > delete</a>
                     </div>
                            <?php endif; ?>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\proyecto-laravel\resources\views/image/detail.blade.php ENDPATH**/ ?>