<?php $__env->startSection('content'); ?>
<div class="container">
      <div class="row justify-content-center">
      <div class="data-pub col-md-6 data-pub-profile">
      <?php echo $__env->make('includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <div class="container-avatar container-avatar-profile">    
                  <img src=" <?php echo e(route('user.avatar', ['filename' => $user->image])); ?> " class="avatar">
              </div>
         
              <div class="data-user-profile">
                  <span class="nick nick-profile">   <?php echo e('@'.$user->nickname); ?></span>        
                      <?php echo e($user->name .' '.$user->surname); ?>

                           <span class="date date-profile" ><?php echo e('Se unio: '.\FormatTime::LongTimeFilter($user->created_at)); ?></span>
              </div>
          
      </div>
        <div class="col-md-7">   
        <?php $__currentLoopData = $user->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('includes/pub',['image' => $image], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\proyecto-laravel\resources\views/user/profile.blade.php ENDPATH**/ ?>